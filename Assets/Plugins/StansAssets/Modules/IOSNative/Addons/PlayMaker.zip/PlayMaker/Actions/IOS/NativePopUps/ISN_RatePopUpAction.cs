﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Pop-ups")]
	[Tooltip("Init Game Cneter. Best practice to do this on appplicaton start")]
	public class ISN_RatePopUpAction : FsmStateAction {
		
		public FsmString title;
		public FsmString message;

		public FsmString yes;
		public FsmString no;
		public FsmString later;

		public FsmEvent yesEvent;
		public FsmEvent noEvent;
		public FsmEvent laterEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public IOSDialogResult ResultInEditor = IOSDialogResult.RATED;

		
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				HandleOnComplete(IOSDialogResult.RATED);
				return;
			}


			IOSRateUsPopUp rate = IOSRateUsPopUp.Create(title.Value, message.Value, yes.Value, later.Value, no.Value);
			rate.OnComplete += HandleOnComplete;
			
		}

	

		public override void Reset() {
			base.Reset();
			
			title 	= "Like this game?";
			message   = "Please rate to support future updates!";
			
			yes 	 = "Okay";
			no	 = "No";
			later  = "Later";
			
		}

		void HandleOnComplete (IOSDialogResult res) {
			switch(res) {
			case IOSDialogResult.RATED:
				Fsm.Event(yesEvent);
				break;
			case IOSDialogResult.REMIND:
				Fsm.Event(laterEvent);
				break;
			case IOSDialogResult.DECLINED:
				Fsm.Event(noEvent);
				break;
				
			}
			
			Finish();
		}

		
	}
}


